#ifndef MONSTER_H
#define MONSTER_H

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <time.h>

class Monster {
private:
	int HP;
	int MaxHP;
	int Attack;
	int Defense;
public:
	Monster(int hp, int mxhp, int atk, int def) :HP(hp), MaxHP(mxhp), Attack(atk), Defense(def) {}
	void setHP(int hp) { HP = hp; }
	int getHP() const { return HP; }
	int getMaxHP() const { return MaxHP; }
	int getAttack() const { return Attack; }
	int getDefense() const { return Defense; }
	void showStats() {//HP MaxHp
		std::cout << std::setw(10) << "Monster(" << std::setw(3) << getHP() << " / " << std::setw(3) << getMaxHP() << " )" << std::endl;
	}
	void attack(Monster& m) {
		m.setHP(m.getHP() - (getAttack() - m.getDefense()));
	}
};
class Dragon :public Monster {


private:
	double Rate;
public:
	Dragon(double k):Monster(300, 300, 100, 50),Rate(k) {}
	void showStats() {//HP MaxHp
		std::cout << std::setw(10) << "Dragon(" << std::setw(3) << getHP() << " / " << std::setw(3) << getMaxHP() << " )" << std::endl;
	}
	void attack(Monster& m) {
		srand((unsigned)time(NULL));
		int n = ((rand() % 10)+1)*Rate;
		
		m.setHP(m.getHP() - (getAttack() - m.getDefense())-n) ;
	}
};
class Unicorn :public Monster {
private:
	int moreAttack[4] = {0,0,1,0};
public:
	Unicorn():Monster(300, 300, 100, 50) {}
	void showStats() {//HP MaxHp
		std::cout << std::setw(10) << "Unicorn(" << std::setw(3) << getHP() << " / " << std::setw(3) << getMaxHP() << " )" << std::endl;
	}
	void attack(Monster& m) {
		srand((unsigned)time(NULL));
		int x = (rand() % 4);
		m.setHP(m.getHP() - (getAttack() - m.getDefense()));
		if (moreAttack[x]==1)
		{
			m.setHP(m.getHP() - (getAttack() - m.getDefense()));
		}
	
	}                          

};


#endif // MONSTER_H

